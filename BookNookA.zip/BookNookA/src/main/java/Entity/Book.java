/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Entity;

/**
 *
 * @author valeriogerardi 10391139
 */

public class Book{
    private String Title;
    private String Author;
    private double price;
    private int sales;
    
    public Book(String Title, String Author, double price){
    this.Title = Title;
    this.Author = Author;
    this.price = price;
    this.sales = 0;
    }
    
    public String getTitle(){
        return Title;
    }
    
    public String getAuthor(){
        return Author;
    }
    
    public double getPrice(){
        return price;
    }
    
    public int getSales(){
        return sales;
    }
    
    public void incrementSales(){
    this.sales++;
    }
}