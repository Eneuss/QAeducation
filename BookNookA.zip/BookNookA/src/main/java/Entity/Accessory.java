/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entity;

/**
 *
 * @author valeriogerardi 10391139
 */

public class Accessory{
    private String Name;
    private double price;
    private int sales;
    
    public Accessory(String name, double price){
        this.Name = name;
        this.price = price;
        this.sales = 0;
        
}
    
    public String getName() {
        return Name;
    }

    public double getPrice() {
        return price;
    }

    public int getSales() {
        return sales;
    }

    public void incrementSales() {
        this.sales++;
    }
}
