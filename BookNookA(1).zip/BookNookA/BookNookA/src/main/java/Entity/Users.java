/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entity;
import Controller.Orders;
import java.util.ArrayList;

/**
 *
 * @author valeriogerardi 10391139
 */
public class Users {
    private String Name;
    private ArrayList<Orders> orderHistory = new ArrayList<>();
    
   
    
    public Users (String Name){
    this.Name = Name;
    }
    
    public void addOrder(Orders order){
    orderHistory.add(order);
    }
    
    public ArrayList<Orders> getOrderHistory(){
    return orderHistory;
    }
    
}

