/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.booknooka;

import Controller.AppManager;
import Entity.Accessory;
import Entity.Book;
import Controller.Orders;
import Entity.Users;
import java.util.ArrayList;
import java.util.Scanner;

public class BookNookA {
    public static void main (String[] args) {
        Scanner scanner = new Scanner(System.in);
        AppManager controller = new AppManager();
        // User user = new User("Gerardi Valerio");

        while (true) {
            System.out.println("\nBookNook Section A Menu, choose from the following options: ");
            System.out.println("1. Search your favourite book"); // Valerio part
            System.out.println("2. Buy your favourite book or accessory");
            System.out.println("3. View your order history");
            System.out.println("4. Exit from the main menu");
            System.out.print("Select an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // start a new line

            switch (choice) {
                case 1: {
                    System.out.println("Digit 1 to search by Title.\nDigit 2 to search by Author: ");
                    int searchOption = scanner.nextInt();
                    scanner.nextLine(); // start a new line
                    System.out.print("Enter your keyword: ");
                    String keyword = scanner.nextLine();

                    ArrayList<Book> results = controller.searchBook(keyword, searchOption == 1);
                    if (results.isEmpty()) {
                        System.out.println("Sorry, there is no book matching your research.");
                    } else {
                        System.out.println("This is what we found for you:");
                        for (Book book : results) {
                            System.out.println("Title: " + book.getTitle() + ", Author: " + book.getAuthor() + ", Price: £" + book.getPrice());
                        }
                    }
                    break;
                }
                case 2: {
                    Orders order = new Orders();

                    while (true) {
                        System.out.println("Good News, your item is available");
                        System.out.println("Books:");
                        ArrayList<Book> books = controller.getBooks();
                        for (int i = 0; i < books.size(); i++) {
                            Book book = books.get(i);
                            System.out.println((i + 1) + ". " + book.getTitle() + " by " + book.getAuthor() + " £" + book.getPrice());
                        }
                        System.out.println("Accessories:");
                        ArrayList<Accessory> accessories = controller.getAccessories();
                        for (int i = 0; i < accessories.size(); i++) {
                            Accessory accessory = accessories.get(i);
                            System.out.println((books.size() + i + 1) + ". " + accessory.getName() + " £" + accessory.getPrice());
                        }
                        System.out.print("Enter the item number you wish to buy (0 to finish): ");
                        int itemNumber = scanner.nextInt();
                        scanner.nextLine(); // start a new line

                        if (itemNumber == 0) break;

                        if (itemNumber > 0 && itemNumber <= books.size()) {
                            Book book = books.get(itemNumber - 1);
                            order.addItem(book.getTitle(), book.getPrice());
                            book.incrementSales();
                        } else if (itemNumber > books.size() && itemNumber <= books.size() + accessories.size()) {
                            Accessory accessory = accessories.get(itemNumber - books.size() - 1);
                            order.addItem(accessory.getName(), accessory.getPrice());
                            accessory.incrementSales();
                        } else {
                            System.out.println("The item number is not recognized.");
                        }
                    }

                    if (!order.getItems().isEmpty()) {
                        // user.addOrder(order);
                        System.out.println("Great news for you! Your order has been placed! The amount is: £" + order.getTotalAmount());
                    } else {
                        System.out.println("Your basket is empty.");
                    }
                    break;
                }
                case 3: {
                    // ArrayList<Order> orders = user.getOrderHistory();
                    ArrayList<Orders> orders = new ArrayList<>(); // Temporary for illustration
                    if (orders.isEmpty()) {
                        System.out.println("There are no orders yet in your history.");
                    } else {
                        System.out.println("This is your order history:");
                        for (int i = 0; i < orders.size(); i++) {
                            Orders order = orders.get(i);
                            System.out.println("Order " + (i + 1) + ":");
                            System.out.println("Items: " + order.getItems());
                            System.out.println("The total amount is: £" + order.getTotalAmount());
                        }
                    }
                    break;
                }
                case 4: {
                    System.out.println("Thank you for using BookNook! See you soon!");
                    return;
                }
                default: {
                    System.out.println("Please try a valid option. Thank you.");
                }
            }
        }
    }
}
