
package Controller;
import java.util.ArrayList;
/**
 *
 * @author valeriogerardi 10391139
 */

public class Orders{
    private ArrayList<String> items = new ArrayList<>();
    private double totalAmount;
    
    public Orders(){
        this.totalAmount = 0.0;
    }
    
    public void addItem(String item, double price){
    items.add(item);
    totalAmount += price;
    }
    
    public ArrayList<String> getItems(){
    return items;
    }
    
    public double getTotalAmount(){
    return totalAmount;
    }
    
}
