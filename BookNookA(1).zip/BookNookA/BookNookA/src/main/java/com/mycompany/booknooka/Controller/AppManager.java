/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;
import Entity.Accessory;
import Entity.Book;
import Controller.Orders;
import Entity.Users;
import java.util.ArrayList;

/**
 *
 * @author valeriogerardi 10391139
 */

public class AppManager{
    private ArrayList<Book> books = new ArrayList<>();
    private ArrayList<Accessory> accessories = new ArrayList<>();
    
    public AppManager(){
        books.add(new Book("Lord Of The Rings Series", "John Ronald Reuel Tolkien", 81.90));
        books.add(new Book("Harry Potter Series", "Joanne Kathleen Rowling", 53.60));
        books.add(new Book("A Court Of Thorns and Roses Series", "Sarah Janet Maas", 48.20));
        books.add(new Book("The Thursday Murder Club Series", "Richard Osman", 31.10));
        books.add(new Book("IT", "Stephen King", 21.00));
        books.add(new Book("Taste: My Life Through Food ", "Stanley Tucci", 11.90));
        books.add(new Book("Shining", "Stephen King", 20.90));
        books.add(new Book("Shutter Island", " Dennis Lehane", 10.30));
        books.add(new Book(" The Alchemist", "Paulo Coelho ", 15.10));
        
       accessories.add(new Accessory("Book Marks", 2.19));
       accessories.add(new Accessory("Book Holders", 5.89));
       accessories.add(new Accessory("Book Lights ", 10.49));
       accessories.add(new Accessory("Book Mugs", 15.69));
       accessories.add(new Accessory("Book Candles", 8.59));
    }
    
public ArrayList<Book> searchBook(String SearchQuery, boolean SearchByTitle){
    ArrayList<Book> results = new ArrayList<>();
    for (Book book : books){
        if (SearchByTitle && book.getTitle().equalsIgnoreCase(SearchQuery)){
            results.add(book);
        } else if (!SearchByTitle&& book.getAuthor().equalsIgnoreCase(SearchQuery)){
            results.add(book);
        }
    }
    return results;
    }
public ArrayList<Accessory> getAccessories(){
    return accessories;
}

public ArrayList<Book> getBooks(){
    return books;
}

}
